<template>
    <div class="group mr-3 cursor-pointer">
      <p><p class="font-bold">?</p>
        <span class="tooltip-text bg-blue-200 p-3 -mt-16 ml-6 rounded hidden group-hover:block absolute py-2 px-6 z-50&quot;">
        <slot></slot>
        </span></p>
    </div>
  </template>
    
<script>
export default {
};
</script>

<style scoped>

</style>